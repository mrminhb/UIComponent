import React, { Component } from "react";
import styled, { css } from "styled-components";
import ForgotPasswordFormMobile from "../components/ForgotPasswordFormMobile";
import HelpButton from "../components/HelpButton";
import LoginSignUpButton from "../components/LoginSignUpButton";

function ForgotPasswordScreenMobile(props) {
  return (
    <Container>
      <ForgotPasswordFormMobile
        style={{
          height: 270,
          width: 350,
          marginTop: 168,
          alignSelf: "center"
        }}
      ></ForgotPasswordFormMobile>
      <HelpButton
        style={{
          height: 60,
          width: 60,
          marginTop: 6,
          marginLeft: 303
        }}
      ></HelpButton>
      <SignUpButtonLayer1Stack>
        <LoginSignUpButton
          style={{
            height: 36,
            width: 100,
            position: "absolute",
            left: 148,
            top: -99
          }}
        ></LoginSignUpButton>
        <LoremIpsum1>Don&#39;t have an account?</LoremIpsum1>
      </SignUpButtonLayer1Stack>
      <TextInput1 placeholder="This is the slogan"></TextInput1>
    </Container>
  );
}

const Container = styled.div`
  display: flex;
  background-color: rgba(74,144,226,1);
  border-width: 1px;
  border-color: rgba(255,255,255,1);
  border-top-width: 100px;
  flex-direction: column;
  border-style: solid;
  height: 100vh;
  width: 100vw;
`;

const LoremIpsum1 = styled.span`
  font-family: Roboto;
  top: -86px;
  left: 0px;
  position: absolute;
  font-style: normal;
  font-weight: 400;
  color: #121212;
  height: 13px;
  width: 152px;
`;

const SignUpButtonLayer1Stack = styled.div`
  width: 248px;
  height: 36px;
  margin-top: -450px;
  margin-left: 115px;
  position: relative;
`;

const TextInput1 = styled.input`
  font-family: Roboto;
  font-style: italic;
  font-weight: 700;
  color: rgba(255,255,255,1);
  height: 39px;
  width: 159px;
  font-size: 20px;
  margin-top: 466px;
  margin-left: 103px;
  border: none;
  background: transparent;
`;

export default ForgotPasswordScreenMobile;
