import React, { Component } from "react";
import styled, { css } from "styled-components";
import SignUpFormMobile from "../components/SignUpFormMobile";
import SignUpLoginButton from "../components/SignUpLoginButton";
import HelpButton from "../components/HelpButton";

function SignUpScreenMobile(props) {
  return (
    <Container>
      <MaterialCardWithoutImageStack>
        <SignUpFormMobile
          style={{
            height: 430,
            width: 350,
            position: "absolute",
            top: 19,
            left: 0
          }}
        ></SignUpFormMobile>
        <AlreadyJoined1>Already joined?</AlreadyJoined1>
        <SignUpLoginButton
          style={{
            height: 36,
            width: 100,
            position: "absolute",
            left: 249,
            top: -99
          }}
        ></SignUpLoginButton>
        <AlreadyJoined2>Already joined?</AlreadyJoined2>
      </MaterialCardWithoutImageStack>
      <HelpButton
        style={{
          height: 60,
          width: 60,
          marginTop: 15,
          marginLeft: 300
        }}
      ></HelpButton>
    </Container>
  );
}

const Container = styled.div`
  display: flex;
  border-width: 1px;
  border-color: rgba(255,255,255,1);
  border-top-width: 100px;
  background-color: rgba(74,144,226,1);
  flex-direction: column;
  border-style: solid;
  height: 100vh;
  width: 100vw;
`;

const AlreadyJoined1 = styled.span`
  font-family: Roboto;
  top: -94px;
  left: 251px;
  position: absolute;
  font-style: normal;
  font-weight: 400;
  color: #121212;
  height: 25px;
  width: 97px;
`;

const AlreadyJoined2 = styled.span`
  font-family: Roboto;
  top: -89px;
  left: 153px;
  position: absolute;
  font-style: normal;
  font-weight: 400;
  color: #121212;
  height: 25px;
  width: 97px;
`;

const MaterialCardWithoutImageStack = styled.div`
  width: 350px;
  height: 449px;
  margin-top: 52px;
  margin-left: 12px;
  position: relative;
`;

export default SignUpScreenMobile;
