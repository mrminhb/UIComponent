import React, { Component } from "react";
import styled, { css } from "styled-components";
import LoginFormMobile from "../components/LoginFormMobile";
import HelpButton from "../components/HelpButton";
import LoginSignUpButton from "../components/LoginSignUpButton";

function LoginFormMobile(props) {
  return (
    <Container>
      <LoginFormMobile
        style={{
          height: 320,
          width: 350,
          marginTop: 141,
          marginLeft: 13
        }}
      ></LoginFormMobile>
      <HelpButton
        style={{
          height: 60,
          width: 60,
          marginTop: 9,
          marginLeft: 303
        }}
      ></HelpButton>
      <TextInput1 placeholder="This is the slogan"></TextInput1>
      <LoremIpsum1Stack>
        <LoremIpsum1>Don&#39;t have an account?</LoremIpsum1>
        <LoginSignUpButton
          style={{
            height: 36,
            width: 100,
            position: "absolute",
            left: 148,
            top: -100
          }}
        ></LoginSignUpButton>
      </LoremIpsum1Stack>
    </Container>
  );
}

const Container = styled.div`
  display: flex;
  border-width: 0px;
  border-color: rgba(255,255,255,1);
  background-color: rgba(74,144,226,1);
  border-right-width: 0px;
  border-bottom-width: 0px;
  border-left-width: 0px;
  border-top-width: 100px;
  flex-direction: column;
  border-style: solid;
  height: 100vh;
  width: 100vw;
`;

const TextInput1 = styled.input`
  font-family: Roboto;
  font-style: italic;
  font-weight: 700;
  color: rgba(255,255,255,1);
  height: 39px;
  width: 159px;
  font-size: 20px;
  margin-top: 29px;
  margin-left: 108px;
  border: none;
  background: transparent;
`;

const LoremIpsum1 = styled.span`
  font-family: Roboto;
  top: -87px;
  left: 0px;
  position: absolute;
  font-style: normal;
  font-weight: 400;
  color: #121212;
  height: 13px;
  width: 152px;
`;

const LoremIpsum1Stack = styled.div`
  width: 248px;
  height: 36px;
  margin-top: -543px;
  margin-left: 115px;
  position: relative;
`;

export default LoginFormMobile;
