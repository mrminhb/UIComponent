import React, { Component } from "react";
import styled, { css } from "styled-components";
import EntypoIcon from "react-native-vector-icons/dist/Entypo";
import ForgotPasswordEmailTextbox2 from "./ForgotPasswordEmailTextbox2";
import ForgotPasswordSendLinkButton from "./ForgotPasswordSendLinkButton";

function ForgotPasswordFormMobile(props) {
  return (
    <Container {...props}>
      <IconRow>
        <EntypoIcon
          name="mail"
          style={{
            color: "rgba(128,128,128,1)",
            fontSize: 40,
            marginTop: 1
          }}
        ></EntypoIcon>
        <ForgotPasswordEmailTextbox2
          style={{
            height: 45,
            width: 275,
            borderWidth: 1,
            borderColor: "#000000",
            borderStyle: "solid"
          }}
        ></ForgotPasswordEmailTextbox2>
      </IconRow>
      <Welcome>Welcome!</Welcome>
      <Email>Email</Email>
      <OrSignIn1>or Sign In</OrSignIn1>
      <ForgotPasswordSendLinkButton
        style={{
          height: 45,
          width: 275,
          marginTop: -90,
          marginLeft: 52
        }}
      ></ForgotPasswordSendLinkButton>
    </Container>
  );
}

const Container = styled.div`
  display: flex;
  border-width: 1px;
  border-radius: 2px;
  border-color: #CCC;
  flex-wrap: nowrap;
  background-color: #FFF;
  overflow: hidden;
  flex-direction: column;
  border-style: solid;
  box-shadow: -2px 2px 1.5px  0.1px #000 ;
`;

const IconRow = styled.div`
  height: 45px;
  flex-direction: row;
  display: flex;
  margin-top: 89px;
  margin-left: 12px;
  margin-right: 23px;
`;

const Welcome = styled.span`
  font-family: Roboto;
  font-style: normal;
  font-weight: 700;
  color: #121212;
  height: 43px;
  width: 275px;
  font-size: 30px;
  text-align: center;
  margin-top: -118px;
  margin-left: 43px;
`;

const Email = styled.span`
  font-family: Roboto;
  font-style: normal;
  font-weight: 400;
  color: #121212;
  height: 20px;
  width: 95px;
  margin-top: 10px;
  margin-left: 52px;
`;

const OrSignIn1 = styled.span`
  font-family: Roboto;
  font-style: normal;
  font-weight: 400;
  color: rgba(189,16,224,1);
  height: 28px;
  width: 71px;
  text-align: center;
  margin-top: 139px;
  margin-left: 145px;
`;

export default ForgotPasswordFormMobile;
