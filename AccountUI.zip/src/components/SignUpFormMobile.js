import React, { Component } from "react";
import styled, { css } from "styled-components";
import IoniconsIcon from "react-native-vector-icons/dist/Ionicons";
import SignUpFormFullNameTextbox2 from "./SignUpFormFullNameTextbox2";
import EntypoIcon from "react-native-vector-icons/dist/Entypo";
import SignUpEmailTextbox2 from "./SignUpEmailTextbox2";
import SignUpPasswordTextbox2 from "./SignUpPasswordTextbox2";
import SignUpJoinNowButton from "./SignUpJoinNowButton";

function SignUpFormMobile(props) {
  return (
    <Container {...props}>
      <LetsGo>Let&#39;s go!</LetsGo>
      <IconRow>
        <IoniconsIcon
          name="md-person"
          style={{
            color: "rgba(128,128,128,1)",
            fontSize: 40,
            marginTop: 22
          }}
        ></IoniconsIcon>
        <MaterialFixedLabelTextboxStack>
          <SignUpFormFullNameTextbox2
            style={{
              height: 45,
              width: 275,
              position: "absolute",
              left: 0,
              top: 21,
              borderWidth: 1,
              borderColor: "#000000",
              borderStyle: "solid"
            }}
          ></SignUpFormFullNameTextbox2>
          <FullName>Full Name</FullName>
        </MaterialFixedLabelTextboxStack>
      </IconRow>
      <Icon2Row>
        <EntypoIcon
          name="mail"
          style={{
            color: "rgba(128,128,128,1)",
            fontSize: 40
          }}
        ></EntypoIcon>
        <SignUpEmailTextbox2
          style={{
            height: 45,
            width: 275,
            borderWidth: 1,
            borderColor: "#000000",
            borderStyle: "solid"
          }}
        ></SignUpEmailTextbox2>
      </Icon2Row>
      <Icon3Row>
        <EntypoIcon
          name="lock"
          style={{
            color: "rgba(128,128,128,1)",
            fontSize: 40,
            marginTop: 22
          }}
        ></EntypoIcon>
        <MaterialFixedLabelTextbox1StackStack>
          <MaterialFixedLabelTextbox1Stack>
            <SignUpPasswordTextbox2
              style={{
                height: 45,
                width: 275,
                position: "absolute",
                left: 0,
                top: 22,
                borderWidth: 1,
                borderColor: "#000000",
                borderStyle: "solid"
              }}
            ></SignUpPasswordTextbox2>
            <ChoosePassword>Choose Password</ChoosePassword>
          </MaterialFixedLabelTextbox1Stack>
          <LoremIpsum></LoremIpsum>
        </MaterialFixedLabelTextbox1StackStack>
      </Icon3Row>
      <SignUpJoinNowButton
        style={{
          height: 45,
          width: 275,
          marginTop: 22,
          marginLeft: 50
        }}
      ></SignUpJoinNowButton>
      <Email>Email</Email>
      <OrSignupWithSso1>or signup with SSO</OrSignupWithSso1>
      <Text1>
        By clicking the button above, you agree to our Terms of Service and
        Privacy Policy
      </Text1>
    </Container>
  );
}

const Container = styled.div`
  display: flex;
  border-width: 1px;
  border-radius: 2px;
  border-color: #CCC;
  flex-wrap: nowrap;
  background-color: #FFF;
  overflow: hidden;
  flex-direction: column;
  border-style: solid;
  box-shadow: -2px 2px 1.5px  0.1px #000 ;
`;

const LetsGo = styled.span`
  font-family: Roboto;
  font-style: normal;
  font-weight: 700;
  color: #121212;
  font-size: 30px;
  margin-top: 16px;
  margin-left: 132px;
`;

const FullName = styled.span`
  font-family: Roboto;
  top: 0px;
  left: 14px;
  position: absolute;
  font-style: normal;
  font-weight: 400;
  color: #121212;
  height: 22px;
  width: 89px;
`;

const MaterialFixedLabelTextboxStack = styled.div`
  width: 275px;
  height: 66px;
  margin-left: 5px;
  position: relative;
`;

const IconRow = styled.div`
  height: 66px;
  flex-direction: row;
  display: flex;
  margin-top: 13px;
  margin-left: 15px;
  margin-right: 34px;
`;

const Icon2Row = styled.div`
  height: 45px;
  flex-direction: row;
  display: flex;
  margin-top: 34px;
  margin-left: 10px;
  margin-right: 34px;
`;

const ChoosePassword = styled.span`
  font-family: Roboto;
  top: 0px;
  left: 14px;
  position: absolute;
  font-style: normal;
  font-weight: 400;
  color: #121212;
  height: 23px;
  width: 115px;
`;

const MaterialFixedLabelTextbox1Stack = styled.div`
  top: 0px;
  left: 0px;
  width: 275px;
  height: 67px;
  position: absolute;
`;

const LoremIpsum = styled.span`
  font-family: Roboto;
  top: 7px;
  left: 14px;
  position: absolute;
  font-style: normal;
  font-weight: 400;
  color: #121212;
  height: 15px;
  width: 61px;
`;

const MaterialFixedLabelTextbox1StackStack = styled.div`
  width: 275px;
  height: 67px;
  position: relative;
`;

const Icon3Row = styled.div`
  height: 67px;
  flex-direction: row;
  display: flex;
  margin-top: 16px;
  margin-left: 10px;
  margin-right: 34px;
`;

const Email = styled.span`
  font-family: Roboto;
  font-style: normal;
  font-weight: 400;
  color: #121212;
  height: 20px;
  width: 60px;
  margin-top: -215px;
  margin-left: 64px;
`;

const OrSignupWithSso1 = styled.span`
  font-family: Roboto;
  font-style: normal;
  font-weight: 400;
  color: rgba(189,16,224,1);
  height: 25px;
  width: 126px;
  margin-top: 210px;
  margin-left: 125px;
`;

const Text1 = styled.span`
  font-family: Roboto;
  font-style: normal;
  font-weight: 400;
  color: rgba(0,0,0,1);
  height: 26px;
  width: 359px;
  font-size: 12px;
  text-align: center;
  background-color: rgba(155,155,155,1);
  margin-top: 5px;
  margin-left: -1px;
`;

export default SignUpFormMobile;
