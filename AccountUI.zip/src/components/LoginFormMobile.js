import React, { Component } from "react";
import styled, { css } from "styled-components";
import EntypoIcon from "react-native-vector-icons/dist/Entypo";
import LoginFormEmailTextbox2 from "./LoginFormEmailTextbox2";
import LoginPasswordTextbox2 from "./LoginPasswordTextbox2";
import LoginFormLoginButton from "./LoginFormLoginButton";

function LoginFormMobile(props) {
  return (
    <Container {...props}>
      <Welcome>Welcome!</Welcome>
      <IconRow>
        <EntypoIcon
          name="mail"
          style={{
            color: "rgba(128,128,128,1)",
            fontSize: 40,
            marginTop: 20
          }}
        ></EntypoIcon>
        <MaterialFixedLabelTextboxStack>
          <LoginFormEmailTextbox2
            style={{
              height: 45,
              width: 275,
              position: "absolute",
              left: 0,
              top: 19,
              borderWidth: 1,
              borderColor: "#000000",
              borderStyle: "solid"
            }}
          ></LoginFormEmailTextbox2>
          <Email>Email</Email>
        </MaterialFixedLabelTextboxStack>
      </IconRow>
      <Icon2Row>
        <EntypoIcon
          name="lock"
          style={{
            color: "rgba(128,128,128,1)",
            fontSize: 40,
            marginTop: 17
          }}
        ></EntypoIcon>
        <MaterialFixedLabelTextboxStack>
          <LoginPasswordTextbox2
            style={{
              height: 45,
              width: 275,
              position: "absolute",
              left: 0,
              top: 17,
              borderWidth: 1,
              borderColor: "#000000",
              borderStyle: "solid"
            }}
          ></LoginPasswordTextbox2>
          <ForgotPassword3>Forgot Password?</ForgotPassword3>
          <Password>Password</Password>
        </MaterialFixedLabelTextboxStack>
      </Icon2Row>
      <LoginFormLoginButton
        style={{
          height: 45,
          width: 275,
          marginTop: 25,
          marginLeft: 51
        }}
      ></LoginFormLoginButton>
      <OrLoginWithSso1>or login with SSO</OrLoginWithSso1>
    </Container>
  );
}

const Container = styled.div`
  display: flex;
  border-width: 1px;
  border-radius: 2px;
  border-color: #CCC;
  flex-wrap: nowrap;
  background-color: #FFF;
  overflow: hidden;
  flex-direction: column;
  border-style: solid;
  box-shadow: -2px 2px 1.5px  0.1px #000 ;
`;

const Welcome = styled.span`
  font-family: Roboto;
  font-style: normal;
  font-weight: 700;
  color: #121212;
  height: 39px;
  width: 137px;
  font-size: 30px;
  margin-top: 14px;
  margin-left: 120px;
`;

const Email = styled.span`
  font-family: Roboto;
  top: 0px;
  left: 1px;
  position: absolute;
  font-style: normal;
  font-weight: 400;
  color: #121212;
  height: 20px;
  width: 82px;
`;

const MaterialFixedLabelTextboxStack = styled.div`
  width: 276px;
  height: 62px;
  margin-left: 1px;
  position: relative;
`;

const IconRow = styled.div`
  height: 64px;
  flex-direction: row;
  display: flex;
  margin-top: 10px;
  margin-left: 9px;
  margin-right: 24px;
`;

const ForgotPassword3 = styled.span`
  font-family: Roboto;
  left: 172px;
  position: absolute;
  font-style: normal;
  font-weight: 400;
  color: rgba(189,16,224,1);
  height: 16px;
  width: 104px;
  top: 31px;
  font-size: 12px;
`;

const Password = styled.span`
  font-family: Roboto;
  top: 0px;
  left: 0px;
  position: absolute;
  font-style: normal;
  font-weight: 400;
  color: #121212;
  height: 18px;
  width: 85px;
`;

const Icon2Row = styled.div`
  height: 62px;
  flex-direction: row;
  display: flex;
  margin-top: 15px;
  margin-left: 9px;
  margin-right: 24px;
`;

const OrLoginWithSso1 = styled.span`
  font-family: Roboto;
  font-style: normal;
  font-weight: 400;
  color: rgba(189,16,224,1);
  height: 25px;
  width: 109px;
  margin-top: 11px;
  margin-left: 133px;
`;

export default LoginFormMobile;
