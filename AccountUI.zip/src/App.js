import React from "react";
import { BrowserRouter as Router, Route } from "react-router-dom";
import "./icons.js";
import ForgotPasswordScreenMobile from "./screens/ForgotPasswordScreenMobile";
import ForgotPasswordScreenPc from "./screens/ForgotPasswordScreenPc";
import LoginFormMobile from "./screens/LoginFormMobile";
import LoginScreenPc from "./screens/LoginScreenPc";
import SignUpScreenMobile from "./screens/SignUpScreenMobile";
import SignUpScreenPc from "./screens/SignUpScreenPc";
import "./style.css";

function App() {
  return (
    <Router>
      <Route path="/" exact component={ForgotPasswordScreenMobile} />
      <Route
        path="/ForgotPasswordScreenMobile/"
        exact
        component={ForgotPasswordScreenMobile}
      />
      <Route
        path="/ForgotPasswordScreenPc/"
        exact
        component={ForgotPasswordScreenPc}
      />
      <Route path="/LoginFormMobile/" exact component={LoginFormMobile} />
      <Route path="/LoginScreenPc/" exact component={LoginScreenPc} />
      <Route path="/SignUpScreenMobile/" exact component={SignUpScreenMobile} />
      <Route path="/SignUpScreenPc/" exact component={SignUpScreenPc} />
    </Router>
  );
}

export default App;
